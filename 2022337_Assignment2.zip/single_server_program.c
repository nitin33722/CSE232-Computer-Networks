#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define TRUE 1


struct process_info {
    char name[256];
    int pid;
    double user_time_sec;
    double system_time_sec;
};

struct process_info* largest_processes(struct process_info *processes_info, size_t num_processes);
struct process_info* check_processes();

struct process_info* largest_processes(struct process_info *processes_info, size_t num_processes) {
    if (num_processes == 0) return NULL;

    struct process_info *largest = (struct process_info*)malloc(2 * sizeof(struct process_info));
    if (largest == NULL) {
        perror("malloc failed");
        exit(1);
    }

    // Initialize to minimum values
    largest[0].user_time_sec = 0;
    largest[1].user_time_sec = 0;

    for (size_t i = 0; i < num_processes; i++) {
        if (processes_info[i].user_time_sec > largest[0].user_time_sec) {
            largest[1] = largest[0];
            largest[0] = processes_info[i];
        } else if (processes_info[i].user_time_sec > largest[1].user_time_sec) {
            largest[1] = processes_info[i];
        }
    }

    return largest;
}


void handle_client(int client_socket) {

    char buffer[1024] = {0};

    while (TRUE) {
        int valread = read(client_socket, buffer, sizeof(buffer) - 1);
        if (valread <= 0) {
            printf("Client disconnected or read error\n");
            break;
        }

        buffer[valread] = '\0';

        if (strcmp(buffer, "exit") == 0) {
            printf("Client disconnected\n");
            break;
        }

        if (strcmp(buffer, "Get") == 0) {
            printf("Received Request\n");

            struct process_info *result = check_processes();

            // Check if result is valid
            if (result != NULL) {
                for (int i = 0 ; i < 2 ; i++){
                    char file_path[256];
                    snprintf(file_path, sizeof(file_path), "/proc/%d/comm", result[i].pid);

                    FILE *file = fopen(file_path, "r");

                    if (file){
                        fgets(result[i].name, sizeof(result[i].name), file);
                        result[i].name[strcspn(result[i].name, "\n")] = '\0';  // Remove newline character
                        fclose(file);

                    }else{
                        strcpy(result[i].name, "Unknown");
                    }
                }
                // Send largest process info
                ssize_t status = send(client_socket, &result[0], sizeof(struct process_info), 0);
                if (status == -1) {
                    perror("Could not send largest process 1");
                }

                status = send(client_socket, &result[1], sizeof(struct process_info), 0);
                if (status == -1) {
                    perror("Could not send largest process 2");
                }

                free(result);
            } else {
                printf("No process info available to send.\n");
            }
        }

        memset(buffer, 0, sizeof(buffer));
    }

    close(client_socket);
    return;
}


struct process_info* check_processes() {
    struct process_info *processes_info = (struct process_info*)malloc(1024 * sizeof(struct process_info)); // allocate a large enough array
    if (processes_info == NULL) {
        perror("malloc failed");
        exit(1);
    }

    size_t process_count = 0;

    DIR *dir = opendir("/proc");
    if (!dir) {
        perror("opendir failed");
        exit(1);
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Check if the entry is a directory and if the name is a number (PID)
        if (entry->d_type == DT_DIR && isdigit(entry->d_name[0])) {
            int pid = atoi(entry->d_name);
            char stat_path[256];
            snprintf(stat_path, sizeof(stat_path), "/proc/%d/stat", pid);

            FILE *stat_file = fopen(stat_path, "r");
            if (stat_file) {
                int ppid;
                double utime, stime;

                // Read the required fields (pid, utime, stime)
                fscanf(stat_file, "%*d %*s %*s %d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %lf %lf", &ppid, &utime, &stime);
                fclose(stat_file);

                processes_info[process_count].pid = pid;
                processes_info[process_count].user_time_sec = utime;
                processes_info[process_count].system_time_sec = stime;
                process_count++;
            }
        }
    }
    closedir(dir);

    processes_info = (struct process_info*)realloc(processes_info, process_count * sizeof(struct process_info));
    if (processes_info == NULL) {
        perror("realloc failed");
        exit(1);
    }

    struct process_info *result = largest_processes(processes_info, process_count);
    free(processes_info);
    return result;
}
   
int main(){

    int sock;
    struct sockaddr_in server_address;
    sock = socket(AF_INET, SOCK_STREAM, 0);

    if (sock == -1){
        perror("Socket creation failed");
        return 1;
    }   

    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8005);
    server_address.sin_addr.s_addr = INADDR_ANY;

    //Binding the socket
    int bind_status;
    bind_status = bind(sock, (struct sockaddr *)&server_address, sizeof(server_address));

    if (bind_status == -1){
        perror("Bind failed");
        return 1;
        close(sock);
    }

    printf("Server is listening\n");

    //Listening for the connection
    if (listen(sock, 10) == -1){
        perror("Listen failed");
        return 1;
        close(sock);
    }

    while (TRUE){
        struct sockaddr_in client_address;
        socklen_t client_address_length = sizeof(client_address);

        int client_socket = accept(sock, (struct sockaddr *)&client_address, &client_address_length);

        if (client_socket == -1){
            perror("Accept failed");
            close(sock);
            continue;
        }


        printf("Connection established\n");
        printf("Client address: %s\n", inet_ntoa(client_address.sin_addr));

        handle_client(client_socket);

    }

    close(sock);

    return 0;
}