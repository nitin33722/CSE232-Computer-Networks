#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/select.h>
#include <errno.h>

#define TRUE 1
#define MAX_CLIENTS 10
#define BUFFER_SIZE 1024

struct process_info {
    char name[256];
    int pid;
    double user_time_sec;
    double system_time_sec;
};

struct process_info* largest_processes(struct process_info *processes_info, size_t num_processes);
struct process_info* check_processes();

struct process_info* largest_processes(struct process_info *processes_info, size_t num_processes) {
    if (num_processes == 0) return NULL;

    struct process_info *largest = (struct process_info*)malloc(2 * sizeof(struct process_info));
    if (largest == NULL) {
        perror("malloc failed");
        exit(1);
    }

    // Initialize to minimum values
    largest[0].user_time_sec = 0;
    largest[1].user_time_sec = 0;

    for (size_t i = 0; i < num_processes; i++) {
        if (processes_info[i].user_time_sec > largest[0].user_time_sec) {
            largest[1] = largest[0];
            largest[0] = processes_info[i];
        } else if (processes_info[i].user_time_sec > largest[1].user_time_sec) {
            largest[1] = processes_info[i];
        }
    }

    return largest;
}

struct process_info* check_processes() {
    struct process_info *processes_info = (struct process_info*)malloc(1024 * sizeof(struct process_info)); // allocate a large enough array
    if (processes_info == NULL) {
        perror("malloc failed");
        exit(1);
    }

    size_t process_count = 0;

    DIR *dir = opendir("/proc");
    if (!dir) {
        perror("opendir failed");
        exit(1);
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Check if the entry is a directory and if the name is a number (PID)
        if (entry->d_type == DT_DIR && isdigit(entry->d_name[0])) {
            int pid = atoi(entry->d_name);
            char stat_path[256];
            snprintf(stat_path, sizeof(stat_path), "/proc/%d/stat", pid);

            FILE *stat_file = fopen(stat_path, "r");
            if (stat_file) {
                int ppid;
                double utime, stime;

                // Read the required fields (pid, utime, stime)
                fscanf(stat_file, "%*d %*s %*s %d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %lf %lf", &ppid, &utime, &stime);
                fclose(stat_file);

                processes_info[process_count].pid = pid;
                processes_info[process_count].user_time_sec = utime;
                processes_info[process_count].system_time_sec = stime;
                process_count++;
            }
        }
    }
    closedir(dir);

    // Resize the processes_info array to the actual number of processes found
    processes_info = (struct process_info*)realloc(processes_info, process_count * sizeof(struct process_info));
    if (processes_info == NULL) {
        perror("realloc failed");
        exit(1);
    }

    struct process_info *result = largest_processes(processes_info, process_count);
    free(processes_info);  // Free the temporary process array
    return result;
}
   
int main(){

    int server_fd, new_socket, client_sockets[MAX_CLIENTS], max_sd, sd;
    struct sockaddr_in server_address;
    fd_set readfds;
    char buffer[BUFFER_SIZE];

    for (int i = 0 ; i < MAX_CLIENTS ; i++){
        client_sockets[i] = 0;
    }
    server_fd = socket(AF_INET, SOCK_STREAM, 0);

    if (server_fd == -1){
        perror("Socket creation failed");
        return 1;
    }  

    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("Setsockopt failed");
        exit(EXIT_FAILURE);
    }


    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8005);
    server_address.sin_addr.s_addr = INADDR_ANY;

    int bind_status;
    bind_status = bind(server_fd, (struct sockaddr *)&server_address, sizeof(server_address));

    if (bind_status == -1){
        perror("Bind Failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 3) == -1){
        perror("Listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }



    int addr_length = sizeof(server_address);
    printf("Listening for connections\n");
    while (TRUE){
        FD_ZERO(&readfds);

        FD_SET(server_fd, &readfds);
        max_sd = server_fd;

        for (int i = 0 ; i < MAX_CLIENTS ; i++){
            sd = client_sockets[i];

            if (sd > 0){
                FD_SET(sd, &readfds);
            }
            if (sd > max_sd){
                max_sd = sd;
            }


        }

        int activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);
        if ((activity < 0) && (errno != EINTR)) {
            perror("Select error");
        }

        if (FD_ISSET(server_fd, &readfds)) {
            if ((new_socket = accept(server_fd, (struct sockaddr*)&server_address, (socklen_t*)&addr_length)) < 0) {
                perror("Accept failed");
                exit(EXIT_FAILURE);
            }

            printf("New connection, socket fd is %d\n", new_socket);

            for (int i = 0; i < MAX_CLIENTS; i++) {
                if (client_sockets[i] == 0) {
                    client_sockets[i] = new_socket;
                    printf("Adding to the list of sockets as %d\n", i);
                    break;
                }
            }
        }

        for (int i = 0; i < MAX_CLIENTS; i++) {
            sd = client_sockets[i];
            if (FD_ISSET(sd, &readfds)) {
                // Check if it was for closing, and also read the incoming message
                int valread = read(sd, buffer, BUFFER_SIZE);
                if (valread == 0) {
                    // Client disconnected
                    getpeername(sd, (struct sockaddr*)&server_address, (socklen_t*)&addr_length);
                    close(sd);
                    client_sockets[i] = 0;
                } else {
                    // Echo back the message to the client
                    buffer[valread] = '\0';
                    
                    if (strcmp (buffer, "Get") == 0){

                        struct process_info *result = check_processes();

                        if (result != NULL){

                            for (int i = 0 ; i < 2 ; i++){
                                char file_path[256];
                                snprintf(file_path, sizeof(file_path), "/proc/%d/comm", result[i].pid);

                                FILE *file = fopen(file_path, "r");

                                if (file){
                                    fgets(result[i].name, sizeof(result[i].name), file);
                                    result[i].name[strcspn(result[i].name, "\n")] = '\0';  // Remove newline character
                                    fclose(file);

                                }else{
                                    strcpy(result[i].name, "Unknown");
                                }
                            }
                            ssize_t status = send(sd, &result[0], sizeof(struct process_info), 0);
                            if (status == -1) {
                                perror("Could not send largest process 1");
                            }

                            status = send(sd, &result[1], sizeof(struct process_info), 0);
                            if (status == -1) {
                                perror("Could not send largest process 2");
                            }

                            free(result);
                        }
                    }
                    else if (strcmp(buffer, "exit") == 0) {
                        printf("Client requested exit, closing connection...\n");
                        close(sd);
                        FD_CLR(sd, &readfds);

                        for (int i = 0; i < MAX_CLIENTS; i++) {
                            if (client_sockets[i] == sd) {
                                client_sockets[i] = 0;
                                break;
                            }
                        }
                    }
                }
            }
        }

    }
    return 0;
}