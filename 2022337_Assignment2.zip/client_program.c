#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#define TRUE 1

struct process_info {
    char name[256];
    int pid;
    double user_time_sec;
    double system_time_sec;
};

void *client_process(void *arg) {
    struct sockaddr_in server_address;    
    char buffer[1024] = {0};

    int client_status = socket(AF_INET, SOCK_STREAM, 0);
    if (client_status == -1) {
        perror("Socket creation failed");
        exit(1);
    }

    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8005);

    if (inet_pton(AF_INET, "192.168.64.3", &server_address.sin_addr) <= 0) {
        perror("Address not supported");
        exit(1);
    }

    int connection_status = connect(client_status, (struct sockaddr *)&server_address, sizeof(server_address));
    if (connection_status == -1) {
        perror("Connection failed");
        exit(1);
    }
    
    // Sending a single request
    char message[] = "Get";
    send(client_status, message, strlen(message), 0);

    struct process_info first;
    int valread = recv(client_status, &first, sizeof(first), 0);
    if (valread <= 0) {
        perror("First Object not received");
    } else {
        printf("Largest Process: \n");
        printf("Process name: %s\n", first.name);
        printf("PID: %d\n", first.pid);
        printf("User time: %f\n", first.user_time_sec);
        printf("System time: %f\n\n", first.system_time_sec);
    }

    struct process_info second;
    valread = recv(client_status, &second, sizeof(second), 0);
    if (valread <= 0) {
        perror("Second Object not received");
    } else {
        printf("Second Largest Process: \n");
        printf("Process name: %s\n", second.name);
        printf("PID: %d\n", second.pid);
        printf("User time: %f\n", second.user_time_sec);
        printf("System time: %f\n\n", second.system_time_sec);
    }

    // Send exit message
    char exit_message[] = "exit";
    send(client_status, exit_message, strlen(exit_message), 0);

    close(client_status);
    return NULL;
}

int main(int argc, char* argv[]) {

	if (argc != 2) {
        fprintf(stderr, "Usage: %s <number_of_clients>\n", argv[0]);
        return 1;
    }

    int no_clients = atoi(argv[1]);
    
    pthread_t threads[no_clients];

    for (int i = 0; i < no_clients; i++) {
        pthread_create(&threads[i], NULL, client_process, NULL);
    }

    for (int i = 0; i < no_clients; i++) {
        pthread_join(threads[i], NULL);
    }

    return 0;
}
